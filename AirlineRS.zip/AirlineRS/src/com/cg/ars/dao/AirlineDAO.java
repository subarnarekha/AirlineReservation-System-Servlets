package com.cg.ars.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.cg.ars.dto.BookingInformationDTO;
import com.cg.ars.dto.BookingsDbDTO;
import com.cg.ars.dto.CustomersDTO;
import com.cg.ars.dto.FlightInformationDTO;
import com.cg.ars.dto.SearchDTO;
import com.cg.ars.dto.SearchResultDTO;
import com.cg.ars.dto.UsersDTO;
import com.cg.ars.exception.ARSException;
import com.cg.ars.util.DbUtil;

public class AirlineDAO implements IAirlineDAO {

	static Connection con = null;
	static Connection con1 = null;
	static PreparedStatement pstm = null;
	static PreparedStatement pstm1 = null;
	static PreparedStatement pstm2=null;
	static PreparedStatement pstm3=null;

	private static final Logger myLogger=Logger.getLogger(AirlineDAO.class);
	
	@Override
	public String loginDb(String username, String password) {
		// TODO Auto-generated method stub
		System.out.println("in dao ");
		String role = null;
		try {

			con = DbUtil.getConnection();
			String query1 = "SELECT role FROM users WHERE username=? AND password=?";
			pstm = con.prepareStatement(query1);
			pstm.setString(1, username);
			pstm.setString(2, password);

			ResultSet res = pstm.executeQuery();
			if (res.next()) {
				System.out.println("in while");
				UsersDTO user = new UsersDTO();
				user.setRole(res.getString("role"));
				role = res.getString("role");
				System.out.println(role);
			} else {
				System.out.println("In else");
				role = "Not Available";
			}

		} catch (SQLException | ARSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				myLogger.info(" Login has a problem "+e.getMessage());
				System.out.println("cannot close insert");
			}
		}
		return role;
	}

	@Override
	public String loginCustomer(String username, String password) {
		// TODO Auto-generated method stub
		System.out.println("in dao LOGIN CUSTOMER ");
		String role = null;
		try {
			con = DbUtil.getConnection();
			String query1 = "SELECT role FROM CUSTOMERS WHERE NAME=? AND PASSWORD=?";
			pstm = con.prepareStatement(query1);
			pstm.setString(1, username);
			pstm.setString(2, password);

			ResultSet res = pstm.executeQuery();
			if (res.next()) {
				System.out.println("in while");
				CustomersDTO cust = new CustomersDTO();
				cust.setRole(res.getString("role"));
				role = res.getString("role");
				System.out.println(role);
			} else {
				System.out.println("In else");
				role = "Not Available";
				System.out.println(role);
			}
		} catch (SQLException | ARSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			myLogger.info(" Login has a problem "+e.getMessage());
		} finally {
			try {
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("cannot close insert");
			}
		}
		return role;

	}

	@Override
	public void flightDb(FlightInformationDTO flight) throws ARSException {

		System.out.println("in dao");
		long ms = System.currentTimeMillis();
		Date d = new Date(ms);

		try {
			con = DbUtil.getConnection();
			System.out.println("after conxn");
			String query = "INSERT INTO FLIGHTINFORMATION VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";
			pstm = con.prepareStatement(query);
			System.out.println("prepared q");
			pstm.setString(1, flight.getFlightNo());
			pstm.setString(2, flight.getAirline());
			pstm.setString(3, flight.getDep_city());
			pstm.setString(4, flight.getArr_city());

			pstm.setDate(5, flight.getDep_date());
			pstm.setDate(6, flight.getArr_date());

			// Date startDate=new
			// SimpleDateFormat("yyyy-MM-dd").parse(flight.getDep_date());
			/*
			 * pstm.setDate(5, (java.sql.Date)flight.getDep_date());
			 * pstm.setDate(6,(java.sql.Date)flight.getArr_date());
			 */
			// pstm.setDate(5,d);
			// pstm.setDate(6,d);
			System.out.println(d);

			pstm.setString(7, flight.getDep_time());
			pstm.setString(8, flight.getArr_time());
			pstm.setString(9, flight.getFirstSeats());
			pstm.setDouble(10, flight.getFirstSeatsFare());
			pstm.setString(11, flight.getBusSeats());
			pstm.setDouble(12, flight.getBusSeatsFare());

			System.out.println("after q");
			int status = pstm.executeUpdate();
			if (status == 1) {
				System.out.println("inserted");

			} else {
				System.out.println("not inserted");

			}

		} catch (ARSException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			myLogger.info(" Problem in inserting flight details"+e.getMessage());
			throw new ARSException("Problem in inserting flight details");
			
		} finally {
			try {
				pstm.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("cannot close insert");
			}

		}

	}

	@Override
	public List<FlightInformationDTO> viewFlightDb() throws ARSException {
		// TODO Auto-generated method stub
		List<FlightInformationDTO> myList = new ArrayList<FlightInformationDTO>();

		try {

			con1 = DbUtil.getConnection();
			String query3 = "SELECT * FROM flightinformation";
			pstm1 = con1.prepareStatement(query3);
			ResultSet res = pstm1.executeQuery();
			while (res.next()) {
				FlightInformationDTO flight = new FlightInformationDTO();
				System.out.println("in while");
				flight.setFlightNo(res.getString("flightno"));
				flight.setAirline(res.getString("airline"));
				flight.setDep_city(res.getString("dep_city"));
				flight.setArr_city(res.getString("arr_city"));
				flight.setDep_date(res.getDate("dep_date"));
				flight.setArr_date(res.getDate("arr_date"));
				flight.setDep_time(res.getString("dep_time"));
				flight.setArr_time(res.getString("arr_time"));
				flight.setFirstSeats(res.getString("firstseats"));
				flight.setFirstSeatsFare(res.getDouble("firstseatfare"));
				flight.setBusSeats(res.getString("bussseats"));
				flight.setBusSeatsFare(res.getDouble("bussseatsfare"));
				System.out.println(res.getString("flightno"));
				myList.add(flight);
			}

		} catch (ARSException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			myLogger.info(" Problem in displaying flight details"+e.getMessage());
			throw new ARSException("Problem in displaying flight details");
		} finally {
			try {
				pstm1.close();
				con1.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("cannot close show");
			}
		}

		return myList;
	}

	@Override
	public List<BookingInformationDTO> viewBookingInfoDb() throws ARSException {
		// TODO Auto-generated method stub
		List<BookingInformationDTO> myList = new ArrayList<BookingInformationDTO>();

		try {
			con1 = DbUtil.getConnection();
			String query3 = "SELECT * FROM bookinginformation";
			pstm1 = con1.prepareStatement(query3);
			ResultSet res = pstm1.executeQuery();
			while (res.next()) {
				BookingInformationDTO booking = new BookingInformationDTO();
				System.out.println("in while");
				booking.setBookingId(res.getInt("booking_id"));
				booking.setCustEmail(res.getString("cust_email"));
				booking.setNoOfPassengers(res.getInt("no_of_passengers"));
				booking.setClassType(res.getString("class_type"));
				booking.setTotalFare(res.getDouble("total_fare"));
				booking.setSeatNumbers(res.getString("seat_number"));
				booking.setCreditCardInfo(res.getString("creditcard_info"));
				booking.setSrcCity(res.getString("src_city"));
				booking.setDestCity(res.getString("dest_city"));
				myList.add(booking);
			}

		} catch (ARSException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new ARSException("Problem in displaying booking info details");
		} finally {
			try {
				pstm1.close();
				con1.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("cannot close show");
			}
		}

		return myList;
	}

	@Override
	public void signUp(String name, String mobile, String pass) {
		// TODO Auto-generated method stub
		try {
			con = DbUtil.getConnection();
			String query2 = "INSERT INTO CUSTOMERS VALUES (?,?,?,null,?,null,'USER')";
			pstm = con.prepareStatement(query2);
			pstm.setString(1, name);
			pstm.setString(2, pass);
			pstm.setString(3, mobile);
			pstm.setString(4, "NIL");

			System.out.println("after q");
			int status = pstm.executeUpdate();
			if (status == 1) {
				System.out.println("inserted");

			} else {
				System.out.println("not inserted");

			}
		} catch (SQLException | ARSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			myLogger.info(" Problem in signing up"+e.getMessage());
		} finally {
			try {

				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("cannot close insert");
			}
		}

	}

	@Override
	public List<FlightInformationDTO> searchFl(SearchDTO search) {
		// TODO Auto-generated method stub
		System.out.println("in dao");
		List<FlightInformationDTO> myList = new ArrayList<FlightInformationDTO>();
		String query2 = null;
		String type = null;
		try {
			con = DbUtil.getConnection();
				type = search.getType();
				if (type.equalsIgnoreCase("FC")) {
					query2 = "SELECT * FROM FLIGHTINFORMATION WHERE DEP_CITY=? AND ARR_CITY=? AND DEP_DATE=? AND FIRSTSEATS>=?";
				} else {
					query2 = "SELECT * FROM FLIGHTINFORMATION WHERE DEP_CITY=? AND ARR_CITY=? AND DEP_DATE=? AND BUSSSEATS>=?";
				}
				pstm = con.prepareStatement(query2);
				pstm.setString(1, search.getSrc());
				pstm.setString(2, search.getDestn());
				pstm.setDate(3, search.getStart());
				int infSeats = search.getInfants();
				int adlSeats = search.getAdults();
				int total = infSeats + adlSeats;
				pstm.setInt(4, total);
		

			ResultSet res = pstm.executeQuery();
			while (res.next()) {
				FlightInformationDTO flight = new FlightInformationDTO();
				System.out.println("in while");
				flight.setFlightNo(res.getString("flightno"));
				flight.setAirline(res.getString("airline"));
				flight.setDep_city(res.getString("dep_city"));
				flight.setArr_city(res.getString("arr_city"));
				flight.setDep_date(res.getDate("dep_date"));
				flight.setArr_date(res.getDate("arr_date"));
				flight.setDep_time(res.getString("dep_time"));
				flight.setArr_time(res.getString("arr_time"));
				flight.setFirstSeats(res.getString("firstseats"));
				flight.setFirstSeatsFare(res.getDouble("firstseatfare"));
				flight.setBusSeats(res.getString("bussseats"));
				flight.setBusSeatsFare(res.getDouble("bussseatsfare"));
				System.out.println(res.getString("flightno"));
				myList.add(flight);
			}


		} catch (SQLException | ARSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			myLogger.info(" Problem in displaying"+e.getMessage());
		} finally {
			try {

				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("cannot close insert");
			}
		}
		return myList;
	}

	@Override
	public void insertSer(List<SearchResultDTO> serdata) {
		// TODO Auto-generated method stub
		try {
			con = DbUtil.getConnection();
			for (SearchResultDTO sResDTO : serdata) {
				String query2 = "INSERT INTO searchdb VALUES (?,?,?,?,?,?,?)";
				pstm = con.prepareStatement(query2);
				pstm.setString(1, sResDTO.getFlightNo());
				pstm.setString(2, sResDTO.getAirline());
				pstm.setString(3, sResDTO.getSrc());
				pstm.setString(4, sResDTO.getDestn());
				pstm.setDouble(5, sResDTO.getTotal_fare());
				pstm.setInt(6, sResDTO.getTotTickets());
				pstm.setString(7, sResDTO.getType());
				System.out.println("after q");
				int status = pstm.executeUpdate();
				if (status == 1) {
					System.out.println("inserted in searchdb");

				} else {
					System.out.println("not inserted");

				}
			}

		} catch (ARSException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {

				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("cannot close insert");
			}
		}
	}

	@Override
	public SearchResultDTO select(String flightNo) {
		List<SearchResultDTO> myList = new ArrayList<SearchResultDTO>();
		SearchResultDTO select = new SearchResultDTO();
		try {
			con = DbUtil.getConnection();
			String query3 = "SELECT * FROM searchdb WHERE flightno=?";
			pstm = con.prepareStatement(query3);
			pstm.setString(1, flightNo);
			ResultSet res = pstm.executeQuery();
			while (res.next()) {
				
				select.setFlightNo(res.getString("flightno"));
				select.setAirline(res.getString("airline"));
				select.setSrc(res.getString("source"));
				select.setDestn(res.getString("destn"));
				select.setTotal_fare(res.getDouble("tot_fare"));
				select.setTotTickets(res.getInt("tot_tickets"));
				select.setType(res.getString("class_type"));
				//myList.add(select);
			}

		} catch (ARSException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			myLogger.info(" Problem in selecting flight"+e.getMessage());
		} finally {
			try {

				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("cannot close insert");
			}
		}

		return select;
	}

	@Override
	public int bookDb(BookingInformationDTO book,String flightnum) throws ARSException {
		String seatS="S";
		System.out.println("in dao");
		int bookingId = 0;
		int seats[] = null;
		int seat=0;
		int nos=book.getNoOfPassengers();
		try {
			con = DbUtil.getConnection();
			System.out.println("after conxn");
			if (con != null) {
				System.out.println("aaaa");
				String query1 = "SELECT booking_seq.NEXTVAL FROM DUAL";
				pstm1 = con.prepareStatement(query1);
				ResultSet resa = pstm1.executeQuery();
				while (resa.next()) {
					bookingId = resa.getInt(1);
					System.out.println(resa.getInt(1));
				}
				for(int i=1;i<=nos;i++){
				String query2 = "SELECT SEQ_101.NEXTVAL FROM DUAL";
				pstm2 = con.prepareStatement(query2);
				ResultSet resb = pstm2.executeQuery();
				int j=0;
				while (resb.next()) {
					
					seat= resb.getInt(1);	
				}
				seatS=seatS+" "+String.valueOf(seat)+",";
				}
				String query = "INSERT INTO bookinginformation VALUES(?,?,?,?,?,?,?,?,?)";
				pstm = con.prepareStatement(query);
				System.out.println("prepared q");
				pstm.setInt(1, bookingId);
				pstm.setString(2, book.getCustEmail());
				pstm.setInt(3, book.getNoOfPassengers());
				pstm.setString(4, book.getClassType());
				pstm.setDouble(5, book.getTotalFare());
				//pstm.setString(6, book.getSeatNumbers());
				
				pstm.setString(6, seatS);
				pstm.setString(7, book.getCreditCardInfo());
				pstm.setString(8, book.getSrcCity());
				pstm.setString(9, book.getDestCity());

				// System.out.println("after q");
				int status = pstm.executeUpdate();
				if (status == 1) {
					System.out.println("inserted");
					String query3 = "INSERT INTO BOOKINGSDB VALUES(?,?,?,?)";
					pstm2 = con.prepareStatement(query3);
					System.out.println("prepared q");
					pstm2.setInt(1, bookingId);
					pstm2.setString(2, flightnum);
					pstm2.setString(3, book.getCustEmail());
					pstm2.setInt(4, book.getNoOfPassengers());
					int status1 = pstm2.executeUpdate();
					if (status1 == 1) {
						System.out.println("inserted in bookingsdb");
					}
				} else {
					System.out.println("not inserted");

				}
				
				/*System.out.println(seats);
				String SeatsF="S";
				for(int j=0;j<=nos;j++){
					SeatsF=SeatsF+seats[j];
				}*/
				
				//String seatNo=(String) seats;
				/*String query = "INSERT INTO bookinginformation VALUES(?,?,?,?,?,?,?,?,?)";
				pstm = con.prepareStatement(query);
				System.out.println("prepared q");
				pstm.setInt(1, bookingId);
				pstm.setString(2, book.getCustEmail());
				pstm.setInt(3, book.getNoOfPassengers());
				pstm.setString(4, book.getClassType());
				pstm.setDouble(5, book.getTotalFare());
				pstm.setString(6, book.getSeatNumbers());
				
				//pstm.setString(6, SeatsF);
				pstm.setString(7, book.getCreditCardInfo());
				pstm.setString(8, book.getSrcCity());
				pstm.setString(9, book.getDestCity());

				// System.out.println("after q");
				int status = pstm.executeUpdate();
				if (status == 1) {
					System.out.println("inserted");
					String query3 = "INSERT INTO BOOKINGSDB VALUES(?,?,?,?)";
					pstm2 = con.prepareStatement(query3);
					System.out.println("prepared q");
					pstm2.setInt(1, bookingId);
					pstm2.setString(2, flightnum);
					pstm2.setString(3, book.getCustEmail());
					pstm2.setInt(4, book.getNoOfPassengers());
					int status1 = pstm2.executeUpdate();
					if (status == 1) {
						System.out.println("inserted in bookingsdb");
					}
				} else {
					System.out.println("not inserted");

				}*/
			}
		} catch (ARSException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			myLogger.info(" Problem in booking ticket"+e.getMessage());
			throw new ARSException("Problem in inserting booking details");

		} finally {
			try {
				if(pstm2!=null)
					pstm2.close();
				if(pstm!=null)
					pstm.close();
					if(pstm1!=null)
						pstm1.close();
					if(con!=null)
					con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("cannot close insert");
			}

		}
		return bookingId;

	}

	public void clearSearch() {
		try {
			con = DbUtil.getConnection();
			String query = "DELETE FROM SEARCHDB";
			pstm = con.prepareStatement(query);
			int status = pstm.executeUpdate();
			if (status == 1) {
				System.out.println("deleted");

			} else {
				System.out.println("not deleted");

			}
		} catch (ARSException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				pstm.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("cannot close insert");
			}
		}
	}

	@Override
	public void update(String flightnum, int numbers, String type) {
		// TODO Auto-generated method stub
		try {
			String query3 = null;
			con = DbUtil.getConnection();
			System.out.println("con complete");
			if (type.equalsIgnoreCase("FC")) {
				query3 = "UPDATE FLIGHTINFORMATION SET firstseats=firstseats-? WHERE flightno=?";
			} else if (type.equalsIgnoreCase("Business")) {
				query3 = "UPDATE FLIGHTINFORMATION SET bussseats=bussseats-? WHERE flightno=?";
			}
			pstm = con.prepareStatement(query3);
			pstm.setInt(1, numbers);
			pstm.setString(2, flightnum);
			int status = pstm.executeUpdate();
			if (status == 1) {
				System.out.println("updated");

			} else {
				System.out.println("not updated");
			}
		} catch (ARSException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {

				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("cannot close update");
			}
		}
	}

	@Override
	public List<FlightInformationDTO> adminSearchOne(Date date, String place) {
		List<FlightInformationDTO> myList = new ArrayList<FlightInformationDTO>();
		try {
			con = DbUtil.getConnection();
			String query ="Select * from FLIGHTINFORMATION where dep_date=? and arr_city=?";
			pstm = con.prepareStatement(query);
			pstm.setDate(1, date);
			pstm.setString(2, place);
			
			ResultSet res = pstm.executeQuery();
			while(res.next()) {
				FlightInformationDTO flight = new FlightInformationDTO();
				System.out.println("in while");
				flight.setFlightNo(res.getString("flightno"));
				flight.setAirline(res.getString("airline"));
				flight.setDep_city(res.getString("dep_city"));
				flight.setArr_city(res.getString("arr_city"));
				flight.setDep_date(res.getDate("dep_date"));
				flight.setArr_date(res.getDate("arr_date"));
				flight.setDep_time(res.getString("dep_time"));
				flight.setArr_time(res.getString("arr_time"));
				flight.setFirstSeats(res.getString("firstseats"));
				flight.setFirstSeatsFare(res.getDouble("firstseatfare"));
				flight.setBusSeats(res.getString("bussseats"));
				flight.setBusSeatsFare(res.getDouble("bussseatsfare"));
				System.out.println(res.getString("flightno"));
				myList.add(flight);
			}
		} catch (ARSException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			myLogger.info(" Problem in searching flightinfo"+e.getMessage());
		}finally {
			try {

				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("cannot close update");
			}
		}
	return	myList;
	}

	@Override
	public void updateCustomers(int id, String mail,String uname) {
		try {
			con = DbUtil.getConnection();
			String query1="commit";
			pstm1 = con.prepareStatement(query1);
			pstm1.executeUpdate();
			System.out.println(uname);
			String query ="UPDATE customers SET BOOKING_ID=? WHERE NAME=?";
			pstm = con.prepareStatement(query);
			//pstm.setString(1, mail);
			//pstm.setString(2, "BOOKED");
			pstm.setInt(1, id);
			pstm.setString(2, uname);
			int status = pstm.executeUpdate();
			if (status == 1) {
				System.out.println("updated bookingid in customers");

			} else {
				System.out.println("not updated");
			}
			String query4="commit";
			pstm1 = con.prepareStatement(query4);
			pstm1.executeUpdate();
			String query2 ="UPDATE customers SET CUST_EMAIL=? WHERE NAME=?";
			pstm2 = con.prepareStatement(query2);
			//pstm.setString(1, mail);
			//pstm.setString(2, "BOOKED");
			pstm2.setString(1, mail);
			pstm2.setString(2, uname);
			int status1 = pstm2.executeUpdate();
			if (status1 == 1) {
				System.out.println("updated mail in customers");

			} else {
				System.out.println("not updated");
			}
			String query5="commit";
			pstm1 = con.prepareStatement(query5);
			pstm1.executeUpdate();
			String query3 ="UPDATE customers SET STATUS=? WHERE NAME=?";
			pstm3 = con.prepareStatement(query3);
			//pstm.setString(1, mail);
			//pstm.setString(2, "BOOKED");
			pstm3.setString(1,"BOOKED" );
			pstm3.setString(2, uname);
			int status2 = pstm3.executeUpdate();
			if (status2 == 1) {
				System.out.println("updated status in customers");

			} else {
				System.out.println("not updated");
			}
		} catch (ARSException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				if (pstm3 != null)
					pstm3.close();
				if (pstm2 != null)
					pstm2.close();
				if (pstm != null)
					pstm.close();
				if (pstm1 != null)
					pstm1.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("cannot close update");
			}
		}
	}

	@Override
	public List<BookingsDbDTO> adminSearchTwo(String flightNum) {
		List<BookingsDbDTO> myList = new ArrayList<BookingsDbDTO>();
		try {
			con = DbUtil.getConnection();
			String query ="Select * from BOOKINGSDB where FLIGHTNO=?";
			pstm = con.prepareStatement(query);
			pstm.setString(1, flightNum);
			System.out.println(flightNum);
			ResultSet res = pstm.executeQuery();
			while (res.next()) {
				BookingsDbDTO bookings = new BookingsDbDTO();
				System.out.println("in while");
				bookings.setBookingId(res.getInt("booking_id"));
				bookings.setFlightNo(res.getString("flightno"));
				bookings.setCustName(res.getString("mail"));
				bookings.setNoOfPassengers(res.getInt("NO_OF_PASSENGERS"));
				System.out.println(res.getString("flightno"));
				myList.add(bookings);
			}
		}catch (ARSException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			myLogger.info(" Problem in display"+e.getMessage());
		}finally {
			try {

				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("cannot close update");
			}
		}
			
		return 	myList;
	}
	@Override
	public List<FlightInformationDTO> showexecDetailsDB(String src,String dest) {
		// TODO Auto-generated method stub
		System.out.println("IN DAO");
		List<FlightInformationDTO> myList=new ArrayList<FlightInformationDTO>();
		try {
			con = DbUtil.getConnection();
			String query="select * from FlightInformation where dep_city=? and arr_city=? ";
			pstm=con.prepareStatement(query);
			pstm.setString(1,src);
			pstm.setString(2,dest);
			ResultSet res=pstm.executeQuery();
			while (res.next()){
				System.out.println("in whiLe");
				FlightInformationDTO dto=new FlightInformationDTO();
				dto.setFlightNo(res.getString(1));
				dto.setAirline(res.getString(2));
				dto.setDep_city(res.getString(3));
				dto.setArr_city(res.getString(4));
				dto.setDep_date(res.getDate(5));
				dto.setArr_date(res.getDate(6));
				dto.setDep_time(res.getString(7));
				dto.setArr_time(res.getString(8));
				dto.setFirstSeats(res.getString(9));
				dto.setFirstSeatsFare(res.getDouble(10));
				dto.setBusSeats(res.getString(11));
				dto.setBusSeatsFare(res.getDouble(12));
				myList.add(dto);
			}
		}catch(Exception e){
			e.printStackTrace();
			myLogger.info(" Problem in display"+e.getMessage());
		}finally {
			try {

				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("cannot close update");
			}}
			return myList;
	}
	@Override
	public List<FlightInformationDTO> showexecDetailsPeriodDB(Date date1,Date date2) {
		// TODO Auto-generated method stub
		List<FlightInformationDTO> myList1=new ArrayList<FlightInformationDTO>();
		try {
			con = DbUtil.getConnection();
			String query2="select * from flightinformation where DEP_DATE BETWEEN ? AND ?";
			pstm=con.prepareStatement(query2);
			pstm.setDate(1,date1);
			pstm.setDate(2,date2);
			ResultSet res=pstm.executeQuery();
			while (res.next()){
				FlightInformationDTO dto=new FlightInformationDTO();
				dto.setFlightNo(res.getString(1));
				dto.setAirline(res.getString(2));
				dto.setDep_city(res.getString(3));
				dto.setArr_city(res.getString(4));
				dto.setDep_date(res.getDate(5));
				dto.setArr_date(res.getDate(6));
				dto.setDep_time(res.getString(7));
				dto.setArr_time(res.getString(8));
				dto.setFirstSeats(res.getString(9));
				dto.setFirstSeatsFare(res.getDouble(10));
				dto.setBusSeats(res.getString(11));
				dto.setBusSeatsFare(res.getDouble(12));
				myList1.add(dto);
			}
		}catch(Exception e){
			e.printStackTrace();
			myLogger.info(" Problem in display"+e.getMessage());
		}finally {
			try {

				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("cannot close update");
			}}	
		
		return myList1;
	}

	@Override
	public List<BookingInformationDTO> showbookingInfo(String email,
			String bookingid) {
		System.out.println("IN DAO");
		System.out.println(bookingid);
		List<BookingInformationDTO> myList2=new ArrayList<BookingInformationDTO>();
		try {
			con = DbUtil.getConnection();
			String query10="select * from bookinginformation where booking_id=? and cust_email=?";
			pstm=con.prepareStatement(query10);
			pstm.setString(1, bookingid);
			pstm.setString(2, email);
			ResultSet res=pstm.executeQuery();
			while (res.next()){
				BookingInformationDTO dto=new BookingInformationDTO();
				dto.setBookingId(res.getInt(1));
				dto.setCustEmail(res.getString(2));
				dto.setNoOfPassengers(res.getInt(3));
				dto.setClassType(res.getString(4));
				dto.setTotalFare(res.getDouble(5));
				dto.setSeatNumbers(res.getString(6));
				dto.setCreditCardInfo(res.getString(7));
				dto.setSrcCity(res.getString(8));
				dto.setDestCity(res.getString(9));
				myList2.add(dto);
				
			}
			
		}catch(Exception e){
			e.printStackTrace();
			myLogger.info(" Problem in display booking info"+e.getMessage());
		}finally {
			try {

				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("cannot close update");
			}}
			return myList2;
		
	}

	@Override
	public String getFlightNumberdb(String bookingid) {
		// TODO Auto-generated method stub
		System.out.println(bookingid);
		String fligthnum=null;
		try {
			con = DbUtil.getConnection();
			String query="select FLIGHTNO from bookingsdb where BOOKING_ID=?";
			pstm=con.prepareStatement(query);
			pstm.setString(1, bookingid);
			ResultSet res=pstm.executeQuery();
			while(res.next()){
				fligthnum=res.getString("FLIGHTNO");
				
				
			}}catch(Exception e){
				e.printStackTrace();
			}finally {
				try {

					if (pstm != null)
						pstm.close();
					if (con != null)
						con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					System.out.println("cannot close update");
				}}
		return fligthnum;
	}

	@Override
	public int getBookingidSession(String username) {
		// TODO Auto-generated method stub
		System.out.println(username);
		int bookingid=0;
		try {
			con = DbUtil.getConnection();
			String query="select BOOKING_ID from bookingsdb where mail=?";
			pstm=con.prepareStatement(query);
			pstm.setString(1,username);
			ResultSet res=pstm.executeQuery();
			while(res.next()){
				bookingid=res.getInt("BOOKING_ID");
			}
					
	}catch(Exception e){
		e.printStackTrace();
	}finally {
		try {

			if (pstm != null)
				pstm.close();
			if (con != null)
				con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("cannot close update");
		}}
		
		return bookingid;
}

	@Override
	public BookingInformationDTO getBookInfo(int bookid2) {
		BookingInformationDTO book=new BookingInformationDTO();
		try {
			con = DbUtil.getConnection();
			String query="select * from bookinginformation where booking_id=?";
			pstm=con.prepareStatement(query);
			pstm.setInt(1,bookid2);
			ResultSet res=pstm.executeQuery();
			if(res.next()){
				
				book.setNoOfPassengers(res.getInt(3));
				book.setClassType(res.getString(4));
				
			}else
			{
				String s1="No data";
				//book=(BookingInformationDTO) s1;
				book=null;
			}
		} catch (ARSException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			myLogger.info(" Problem in display"+e.getMessage());
		}
		return book;
	}

	@Override
	public void updateOnCancel(int nos, String classType, String fnum) {
		String query3=null;
		try {
			con = DbUtil.getConnection();
			if (classType.equalsIgnoreCase("FC")) {
				query3 = "UPDATE FLIGHTINFORMATION SET firstseats=firstseats+? WHERE flightno=?";
			} else if (classType.equalsIgnoreCase("Business")) {
				query3 = "UPDATE FLIGHTINFORMATION SET bussseats=bussseats+? WHERE flightno=?";
			}
			pstm = con.prepareStatement(query3);
			pstm.setInt(1, nos);
			pstm.setString(2, fnum);
			int status = pstm.executeUpdate();
			if (status == 1) {
				System.out.println("updated flightinfo on cancel");

			} else {
				System.out.println("not updated");
			}
			
		} catch (ARSException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}finally {
			try {

				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("cannot close update");
			}}
		
	}

	@Override
	public int cancelTicket(int bookid2) {
		int status=0;
		try {
			con = DbUtil.getConnection();
			String query = "DELETE FROM bookinginformation WHERE booking_id=? ";
			pstm = con.prepareStatement(query);
			pstm.setInt(1, bookid2);
			status = pstm.executeUpdate();
			if (status == 1) {
				System.out.println("deleted on cancel");

			} else {
				System.out.println("not deleted");

			}
		} catch (ARSException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			myLogger.info(" Problem in cancelling"+e.getMessage());
		} finally {
			try {
				pstm.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("cannot close insert");
			}
		}
		return status;
	}

	@Override
	public String getFlightInfo(String flightnum,String type) {
		String query=null;
		String fs=null;
		FlightInformationDTO book=new FlightInformationDTO();
		try {
			con = DbUtil.getConnection();
			if(type.equals("FC")){
				query="SELECT FIRSTSEATS FROM FLIGHTINFORMATION WHERE FLIGHTNO=?";
				pstm = con.prepareStatement(query);
				pstm.setString(1, flightnum);
				ResultSet res=pstm.executeQuery();
				while(res.next()){
					book.setFirstSeats(res.getString("FIRSTSEATS"));
					fs=res.getString("FIRSTSEATS");
					int fsnum=Integer.parseInt(fs);
					System.out.println(fs);
				}
			}
				else if(type.equals("Business")){
					query="SELECT BUSSSEATS FROM FLIGHTINFORMATION WHERE FLIGHTNO=?";
					pstm = con.prepareStatement(query);
					pstm.setString(1, flightnum);
					ResultSet res=pstm.executeQuery();
					while(res.next()){
						book.setFirstSeats(res.getString("BUSSSEATS"));
						fs=res.getString("BUSSSEATS");
						int fsnum=Integer.parseInt(fs);
						System.out.println(fs);
					}
				}		
		} catch (ARSException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				pstm.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("cannot close insert");
			}
		}
		return fs;
	}

	/*@Override
	public int createSeq(int seatN, String flightnum) {
		int status=0;
		System.out.println("In create seq");
		try {
			con = DbUtil.getConnection();
			String query="CREATE SEQUENCE seat_seq START WITH 1 MAXVALUE ?";
			pstm = con.prepareStatement(query);
			System.out.println("qery seq done");
			//pstm.setString(1, "seq_"+flightnum);
			
			pstm.setInt(1,seatN);
			status = pstm.executeUpdate();
			if (status == 1) {
				System.out.println("sequence created");

			} else {
				System.out.println("sequence not created");

			}
			
		} catch (ARSException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				pstm.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("cannot close insert");
			}
		}
		return status;
	}
	*/
}
