package com.cg.ars.unittest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.ars.dto.FlightInformationDTO;
import com.cg.ars.dto.UsersDTO;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AirlineDAOTest {

	Connection con=null;
	PreparedStatement pstm=null;
	
	
	@Before
	public void setUpConnection() throws SQLException{
		con=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:ORCL","trg233","training233");
		
	
	
	}
	
	@Test
	public void testLoginAdmin() throws SQLException {
		String role=null;
		String query1 = "SELECT role FROM users WHERE username=? AND password=?";
		pstm=con.prepareStatement(query1);
		pstm.setString(1, "Admin1");
		pstm.setString(2, "1001");
		ResultSet res = pstm.executeQuery();
		//fail("Not yet implemented");
		if (res.next()) {
			//System.out.println("in while");
			//UsersDTO user = new UsersDTO();
			//user.setRole(res.getString("role"));
			role = res.getString("role");
			//System.out.println(role);
		} else {
			System.out.println("In else");
			role = "Not Available";
		}
		assertEquals("ADMIN",role);
		
	}
	@Test
	public void testLoginExec() throws SQLException {
		String role=null;
		String query1 = "SELECT role FROM users WHERE username=? AND password=?";
		pstm=con.prepareStatement(query1);
		pstm.setString(1, "Exec1");
		pstm.setString(2, "1002");
		ResultSet res = pstm.executeQuery();
		//fail("Not yet implemented");
		if (res.next()) {
			//System.out.println("in while");
			//UsersDTO user = new UsersDTO();
			//user.setRole(res.getString("role"));
			role = res.getString("role");
			//System.out.println(role);
		} else {
			System.out.println("In else");
			role = "Not Available";
		}
		assertEquals("EXECUTIVE",role);
		
	}
	
	@Test
	public void testBookTickets() throws SQLException{
		String query = "INSERT INTO bookinginformation VALUES(?,?,?,?,?,?,?,?,?)";
		pstm = con.prepareStatement(query);
		//System.out.println("prepared q");
		pstm.setInt(1, 1234);
		pstm.setString(2, "swami@gmail.com");
		pstm.setInt(3, 2);
		pstm.setString(4,"FC");
		pstm.setDouble(5, 5255.5225);
		//pstm.setString(6, book.getSeatNumbers());
		
		pstm.setString(6, "23,24");
		pstm.setString(7, "1245678920");
		pstm.setString(8, "CHENNAI");
		pstm.setString(9, "PUNE");
		assertEquals(1,pstm.executeUpdate());
	}
	
	@Test
	public void viewFlightScheduleTest() throws SQLException{
		List<FlightInformationDTO> myList = new ArrayList<FlightInformationDTO>();
		int status=0;
		String query3 = "SELECT * FROM flightinformation";
		pstm = con.prepareStatement(query3);
		ResultSet res = pstm.executeQuery();
		while (res.next()) {
			FlightInformationDTO flight = new FlightInformationDTO();
			status=1;
			flight.setFlightNo(res.getString("flightno"));
			flight.setAirline(res.getString("airline"));
			flight.setDep_city(res.getString("dep_city"));
			flight.setArr_city(res.getString("arr_city"));
			flight.setDep_date(res.getDate("dep_date"));
			flight.setArr_date(res.getDate("arr_date"));
			flight.setDep_time(res.getString("dep_time"));
			flight.setArr_time(res.getString("arr_time"));
			flight.setFirstSeats(res.getString("firstseats"));
			flight.setFirstSeatsFare(res.getDouble("firstseatfare"));
			flight.setBusSeats(res.getString("bussseats"));
			flight.setBusSeatsFare(res.getDouble("bussseatsfare"));
			
			myList.add(flight);
		}
			assertEquals(1,status);
		
	}
	
	@After
	 public void afterTestLogin() throws SQLException{
		pstm.close();
		con.close();
	}
	
	

}
