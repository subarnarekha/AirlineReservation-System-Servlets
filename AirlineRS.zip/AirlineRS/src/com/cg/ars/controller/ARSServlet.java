package com.cg.ars.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.sql.Date;
import java.sql.PreparedStatement;

import com.cg.ars.dto.BookingInformationDTO;
import com.cg.ars.dto.BookingsDbDTO;
import com.cg.ars.dto.FlightInformationDTO;
import com.cg.ars.dto.LoginTypeDTO;
import com.cg.ars.dto.SearchDTO;
import com.cg.ars.dto.SearchResultDTO;
import com.cg.ars.exception.ARSException;
import com.cg.ars.service.AirlineService;
import com.cg.ars.service.IAirlineService;

/**
 * Servlet implementation class ARSServlet
 */
@WebServlet("*.obj")
public class ARSServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ARSServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		System.out.println("in post");
		RequestDispatcher dispatcher = null;
		HttpSession session = request.getSession();
		IAirlineService airSer = new AirlineService();

		String target = "";
		String targetSuccess = "/success.jsp";
		String targetAddFlights = "/AdminAddFlights.jsp";
		String targetHome = "/index.jsp";
		String targetAdminFirst = "/AdminMenus.jsp";
		String targetFlightView = "/AdminViewFlights.jsp";
		String targetReservnView = "/AdminViewResrvn.jsp";
		String targetUser = "/userPgOne.jsp";
		//String targetUser = "/userPgOne.html";
		String targetAdmin = "/AdminMenus.jsp";
		String targetExecutive = "/flightexec1.jsp";
		String targetLogin = "/index.jsp";
		String targetSearchResults = "/searchResults.jsp";
		String targetSignup = "/signup.html";
		String targetBookInfo = "/BookInfo.jsp";
		String targetBookResults = "/bookResults.jsp";
		String targetBooked="/report.jsp";
		String targetexecsd="/sourcedest.jsp";
		String targetexecdp="/dateperiod.jsp";
		String targetdetailsexec1="/Details.jsp";
		String targetdetailsexec2="/Details1.jsp";
		String targetBookinfo="/Bookingresults.jsp";
		String targetCancelled="/cancelled.jsp";
		String targetAdminsError="/AdminErrorPage.jsp";
		String targetUserErr="/UserError.jsp";
		
		String path = request.getServletPath().trim();

		switch (path) {

		case "/Create.obj":
			target = targetSignup;
			break;

		case "/SignUp.obj":
			String nameS = request.getParameter("uname");
			String passS = request.getParameter("psw");
			String mobS = request.getParameter("mob");
				session.setAttribute("uname", nameS);
			airSer.signUp(nameS, mobS, passS);
			target = targetUser;
			break;

		case "/AdminMenus.obj":
			target = targetAdminFirst;
			break;

		case"/Back Admin.obj":
			target = targetAdminFirst;
			break;
			
		case "/User Back.obj":
			target = targetUser;
			break;
			
		case "/Back.obj":
			target = targetHome;
			break;

		case "/Menu Add Flights.obj":
			target = targetAddFlights;
			break;

		case "/Add Flight Detail.obj":
			try {
				FlightInformationDTO flight = new FlightInformationDTO();

				String sfNum = request.getParameter("flight_no");
				int fnum = Integer.parseInt(sfNum);
				String airline = request.getParameter("Airline");

				String depCity = request.getParameter("dep_city");
				String arrCity = request.getParameter("arr_city");

				System.out.println("b4 date");
				String sdepDate = request.getParameter("dep_date");
				Date startDate = Date.valueOf(sdepDate);
				// Date startDate= new
				// SimpleDateFormat("yyyy-MM-dd").parse(request.getParameter("dep_date"));
				// //get the parameter convert it to a data type Date.
				// Date index1;
				// PreparedStatement.setDate(index1,new
				// java.sql.Date(startDate.getTime()));

				System.out.println(startDate);
				// Date depDate=new Date(sdepDate);

				String sarrDate = request.getParameter("arr_date");
				Date endDate = Date.valueOf(sarrDate);

				// Date endDate= new
				// SimpleDateFormat("yyyy-MM-dd").parse(request.getParameter("arr_date"));
				System.out.println(endDate);

				// Date arrDate=new Date(sarrDate);
				System.out.println("after date");

				String depTime = request.getParameter("dep_time");
				String arrTime = request.getParameter("arr_time");

				String fsSeats = request.getParameter("fs_seats");
				String fsFare = request.getParameter("fs_fare");
				double dFsFare = Double.parseDouble(fsFare);

				String bsSeats = request.getParameter("bs_seats");
				String bsFare = request.getParameter("bs_fare");
				double dBsFare = Double.parseDouble(bsFare);

				System.out.println("");
				flight.setFlightNo(sfNum);
				flight.setAirline(airline);
				flight.setDep_city(depCity);
				flight.setArr_city(arrCity);
				flight.setDep_date(startDate);
				flight.setArr_date(endDate);
				/*
				 * flight.setDep_date(depDate); flight.setArr_date(arrDate);
				 */
				flight.setDep_time(depTime);
				flight.setArr_time(arrTime);
				flight.setFirstSeats(fsSeats);
				flight.setFirstSeatsFare(dFsFare);
				flight.setBusSeats(bsSeats);
				flight.setBusSeatsFare(dBsFare);

				airSer.insertFlight(flight);
				request.setAttribute("airline", airline);
				System.out.println("Inserted");

			} catch (ARSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			target = targetSuccess;
			break;

		case "/Menu View Flights.obj":
			List<FlightInformationDTO> flightList = new ArrayList<FlightInformationDTO>();
			try {
				flightList = airSer.viewFlight();
				request.setAttribute("flights", flightList);
			} catch (ARSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(!flightList.isEmpty()){
				target = targetFlightView;
				}else{
					target = targetAdminsError;
				}
			
			break;

		case "/Menu View Reservation.obj":
			List<BookingInformationDTO> bookingList = new ArrayList<BookingInformationDTO>();
			try {
				bookingList = airSer.viewBookingInfo();
				request.setAttribute("bookInf", bookingList);
			} catch (ARSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(!bookingList.isEmpty()){
			target = targetReservnView;
			}else{
				target = targetAdminsError;
			}
			break;
			
		case "/Report View.obj":
			String targetReportView="/reportview.jsp";
			target = targetReportView;
			break;

		case "/Login.obj":
			LoginTypeDTO user=new LoginTypeDTO();
			String name = request.getParameter("username");
			String pass = request.getParameter("password");
			String log1 = "USER";
			String log2 = "ADMIN";
			String log3 = "EXECUTIVE";
			String flag = "Not Available";
			session.setAttribute("uname", name);
			String role = airSer.login(name, pass);
			//user.setRole(role);
			System.out.println("login"+role);
			if (role.equals(flag)) {
				String roleCust=airSer.loginCustomer(name, pass);
				System.out.println("LOGIN CUST"+roleCust);
				if (roleCust.equals(flag)) {
					request.setAttribute("msg", "Invalid Login Credentials");
					target = targetLogin;
				}else if(roleCust.equals(log1)){
					target=targetUser;
				}else {
					request.setAttribute("msg", "Invalid Login Credentials");
					target = targetLogin;	
				}
			} else if (role.equals(log2)) {
				target = targetAdmin;
			} else if (role.equals(log3)) {
				target = targetExecutive;
			} 
			break;

		case "/Search.obj":
			List<SearchResultDTO> flightSearList = new ArrayList<SearchResultDTO>();
			SearchDTO search = new SearchDTO();

			//String trip = request.getParameter("radio");
			
				String src = request.getParameter("user1");
				String destn = request.getParameter("user2");
				String sDate1 = request.getParameter("departdate");
				Date start = Date.valueOf(sDate1);
				String sInf = request.getParameter("infant");
				int inf = Integer.parseInt(sInf);
				String sAdlt = request.getParameter("adult");
				int adlt = Integer.parseInt(sAdlt);
				String sclass = request.getParameter("class");

				search.setSrc(src);
				search.setDestn(destn);
				search.setStart(start);

				search.setInfants(inf);
				search.setAdults(adlt);
				search.setType(sclass);
				request.setAttribute("stdate", start);
				request.setAttribute("date", "Start Date is " + start);
			
			flightSearList = airSer.searchFl(search);
			request.setAttribute("flightsSerch", flightSearList);
			airSer.insertSer(flightSearList);
			request.setAttribute("flag", 1);
			
			if(!flightSearList.isEmpty()){
				target = targetSearchResults;
				}else{
					target = targetAdminsError;
				}
			break;

		case "/Select Flight.obj":
			List<SearchResultDTO> selectedFlight = new ArrayList<SearchResultDTO>();
			SearchResultDTO selected=new SearchResultDTO();
			String sflightNo = request.getParameter("fid");
			// int flightNo=Integer.parseInt(sflightNo);
			System.out.println(sflightNo);
			//selectedFlight = airSer.select(sflightNo);
			selected=airSer.select(sflightNo);
			session.setAttribute("flightNo", sflightNo);
			request.setAttribute("flightSelected", selected);
			//request.setAttribute("flightSelected", selectedFlight);
			target = targetBookInfo;
			break;

			
		case "/Book.obj":
			BookingInformationDTO book = new BookingInformationDTO();
			FlightInformationDTO flight=new FlightInformationDTO();
			String mail = request.getParameter("mail");
			String snumber = request.getParameter("number");
			int number = Integer.parseInt(snumber);
			String type = request.getParameter("class");
			String sfare = request.getParameter("fare");
			double fare = Double.parseDouble(sfare);
			//String seat = request.getParameter("seat");
			String credit = request.getParameter("credit");
			String source = request.getParameter("source");
			String destination = request.getParameter("destination");
			book.setCustEmail(mail);
			book.setNoOfPassengers(number);
			book.setClassType(type);
			book.setTotalFare(fare);
			book.setSeatNumbers("23");
			book.setCreditCardInfo(credit);
			book.setSrcCity(source);
			book.setDestCity(destination);
			try {
				
				String flightnum=(String) session.getAttribute("flightNo");
				String uname=(String) session.getAttribute("uname");
				
				String seats=airSer.getFlightInfo(flightnum,type);
				int seatN=Integer.parseInt(seats);
				
				//airSer.createSeq(seatN,flightnum);
				
				int id=airSer.bookDb(book,flightnum);
				session.setAttribute("bid", id);
				airSer.update(flightnum,number,type);
				airSer.updateCustomers(id,mail,uname);
				airSer.clearSearch();
			} catch (ARSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			target = targetBooked;
			break;
		
		case "/Admin Report.obj":
			String option = request.getParameter("radio");
			if(option.equals("option1")){
				String targetSearchPgOne="/searchPgOne.jsp";
				target = targetSearchPgOne;
			}
			else if(option.equals("option2")){
				String targetSearchPgTwo="/SearchPgTwo.jsp";
				target = targetSearchPgTwo;
			}
			else if(option.equals("option3")){
				String targetSearchPgThree="/searchPgThree.jsp";
				target = targetSearchPgThree;
			}
			break;
			
		case "/Admin Search One.obj":
			List<FlightInformationDTO> searchResultsOne = new ArrayList<FlightInformationDTO>();
			String date = request.getParameter("date");
			Date date1 = Date.valueOf(date);
			String place = request.getParameter("place");
			searchResultsOne=airSer.adminSearchOne(date1,place);
			request.setAttribute("flights", searchResultsOne);
			String targetResSearchPgOne="/results1.jsp";
			
			if(!searchResultsOne.isEmpty()){
				target = targetResSearchPgOne;
				}else{
					target = targetAdminsError;
				}
			break;
			
		case "/Admin Search Two.obj":
			List<BookingsDbDTO> searchResultsTwo = new ArrayList<BookingsDbDTO>();
			String flightNum = request.getParameter("fnumber");
			searchResultsTwo=airSer.adminSearchTwo(flightNum);
			request.setAttribute("flights", searchResultsTwo);
			String targetResSearchPgTwo="/results2.jsp";
			
			if(!searchResultsTwo.isEmpty()){
				target = targetResSearchPgTwo;
				}else{
					target = targetAdminsError;
				}
			break;
			
		case "/one.obj":
			target=targetexecsd;
			break;
			
		case "/two.obj":
			target=targetexecdp;
			break;
			
		case "/sub.obj":
			List<FlightInformationDTO> flightList4=new ArrayList<FlightInformationDTO>();
			String src1=request.getParameter("source");
			String dest=request.getParameter("destination");
			/*dto.setArr_city(dest);
			dto.setDep_city(src);*/
			flightList4=airSer.showexecDetails(src1, dest);
			
			request.setAttribute("info", flightList4);
			target=targetdetailsexec1;
			if(!flightList4.isEmpty()){
				target=targetdetailsexec1;
				}else{
					target = targetAdminsError;
				}
			break;
			
		case "/sd2.obj":
			List<FlightInformationDTO> flightList2=new ArrayList<FlightInformationDTO>();
			String depdate1=request.getParameter("depdate1");
			Date date11=Date.valueOf(depdate1);
			String depdate2=request.getParameter("depdate2");
			Date date2=Date.valueOf(depdate2);
/*			dto.setDep_date(date1);
			dto.setDep_date(date2);
*/			flightList2=airSer.showexecDetailsPeriodDB(date11, date2);
			request.setAttribute("info1", flightList2);
			if(!flightList2.isEmpty()){
				target=targetdetailsexec2;
				}else{
					target = targetAdminsError;
				}
			break;
			
		case "/search1.obj":
			List<BookingInformationDTO> bookingList1=new ArrayList<BookingInformationDTO>();
			String email=request.getParameter("email");
			String bookingid=request.getParameter("bookingid");
			int bookid=Integer.parseInt(bookingid);
			System.out.println(bookingid);
			String uname=(String) session.getAttribute("uname");
			//int bookingid10=airSer.getBookingidSession(uname);
			request.setAttribute("flag", 2);
			//if(bookingid10==bookid){
				String flightNum11=airSer.getFlightNumber(bookingid);
				request.setAttribute("flightNum", flightNum11);
				bookingList1=airSer.showbookingInfo(email, bookingid);
				if(!bookingList1.isEmpty()){
				request.setAttribute("info2", bookingList1);
				target=targetBookinfo;
				}else{
					target = targetAdminsError;
				}
				
			/*//}else
			{
				request.setAttribute("message", "Not valid");
				target=targetBookinfo;
			}*/
			
			break;
			
		case "/search2.obj":
			BookingInformationDTO bookinf=new BookingInformationDTO();
			String bookingid2=request.getParameter("bookingid");
			int bookid2=Integer.parseInt(bookingid2);
			bookinf=airSer.getBookInfo(bookid2);
			if(bookinf!=null){
			int nos=bookinf.getNoOfPassengers();
			String classType=bookinf.getClassType();
			String fnum=airSer.getFlightNumber(bookingid2);
			airSer.updateOnCancel(nos,classType,fnum);
			int cacelStatus=airSer.cancelTicket(bookid2);
			if(cacelStatus==1){
				request.setAttribute("cancelled","Cancelled your ticket with booking id:"+bookingid2);
			target=targetCancelled;
			}else{
				request.setAttribute("cancelled","Not Cancelled");
				target=targetCancelled;
				}
			}
			else{
				target = targetAdminsError;
			}
			break;
		
		case "/logout.obj":
			if(session!=null){
				session.removeAttribute("uname");
				session.invalidate();
				response.sendRedirect("index.jsp");
			}
		
		break;
		}

		dispatcher = getServletContext().getRequestDispatcher(target);
		dispatcher.forward(request, response);

		// session.setAttribute(fnum);

	}

}
