package com.cg.ars.dto;

public class BookingsDbDTO {

	public int bookingId;
	public String flightNo;
	public String custName;
	public int noOfPassengers;
	
	@Override
	public String toString() {
		return "BookingsDbDTO [bookingId=" + bookingId + ", flightNo="
				+ flightNo + ", custName=" + custName + ", noOfPassengers="
				+ noOfPassengers + "]";
	}
	public int getBookingId() {
		return bookingId;
	}
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}
	public String getFlightNo() {
		return flightNo;
	}
	public void setFlightNo(String flightNo) {
		this.flightNo = flightNo;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public int getNoOfPassengers() {
		return noOfPassengers;
	}
	public void setNoOfPassengers(int noOfPassengers) {
		this.noOfPassengers = noOfPassengers;
	}
	
	
}
