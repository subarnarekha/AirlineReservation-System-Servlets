package com.cg.ars.dto;

import java.sql.Date;

public class SearchResultDTO {

	String flightNo;
	String airline;
	String src;
	String destn;
	double total_fare;
	int totTickets;
	double seatsFare;
	String duration;
	private Date dep_date;
	private Date arr_date;
	private String dep_time;
	private String arr_time;
	private String firstSeats;
	private String busSeats;
	String trip;
	String type;
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public double getSeatsFare() {
		return seatsFare;
	}
	public void setSeatsFare(double seatsFare) {
		this.seatsFare = seatsFare;
	}
	public int getTotTickets() {
		return totTickets;
	}
	public void setTotTickets(int totTickets) {
		this.totTickets = totTickets;
	}
	
	
	
	
	public String getTrip() {
		return trip;
	}
	public void setTrip(String trip) {
		this.trip = trip;
	}
	public Date getDep_date() {
		return dep_date;
	}
	public void setDep_date(Date dep_date) {
		this.dep_date = dep_date;
	}
	public Date getArr_date() {
		return arr_date;
	}
	public void setArr_date(Date arr_date) {
		this.arr_date = arr_date;
	}
	public String getDep_time() {
		return dep_time;
	}
	public void setDep_time(String dep_time) {
		this.dep_time = dep_time;
	}
	public String getArr_time() {
		return arr_time;
	}
	public void setArr_time(String arr_time) {
		this.arr_time = arr_time;
	}
	public String getFirstSeats() {
		return firstSeats;
	}
	public void setFirstSeats(String firstSeats) {
		this.firstSeats = firstSeats;
	}
	public String getBusSeats() {
		return busSeats;
	}
	public void setBusSeats(String busSeats) {
		this.busSeats = busSeats;
	}
	
	
	public String getFlightNo() {
		return flightNo;
	}
	public void setFlightNo(String flightNo2) {
		this.flightNo = flightNo2;
	}
	public String getAirline() {
		return airline;
	}
	public void setAirline(String airline) {
		this.airline = airline;
	}
	public String getSrc() {
		return src;
	}
	public void setSrc(String src) {
		this.src = src;
	}
	public String getDestn() {
		return destn;
	}
	public void setDestn(String destn) {
		this.destn = destn;
	}
	public double getTotal_fare() {
		return total_fare;
	}
	public void setTotal_fare(double total_fare) {
		this.total_fare = total_fare;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	@Override
	public String toString() {
		return "SearchResultDTO [flightNo=" + flightNo + ", airline=" + airline
				+ ", src=" + src + ", destn=" + destn + ", total_fare="
				+ total_fare + ", totTickets=" + totTickets + ", seatsFare="
				+ seatsFare + ", duration=" + duration + ", dep_date="
				+ dep_date + ", arr_date=" + arr_date + ", dep_time="
				+ dep_time + ", arr_time=" + arr_time + ", firstSeats="
				+ firstSeats + ", busSeats=" + busSeats + ", trip=" + trip
				+ ", type=" + type + "]";
	}

	
 
	
}
