package com.cg.ars.dto;

import java.sql.Date;



public class FlightInformationDTO {
	
	private String flightNo;
	private String airline;
	private String dep_city;
	private String arr_city;
	private Date dep_date;
	private Date arr_date;
	private String dep_time;
	private String arr_time;
	private String firstSeats;
	private Double firstSeatsFare;
	private String busSeats;
	private Double busSeatsFare;
	
	public FlightInformationDTO() {
		super();
	}

	public FlightInformationDTO(String flightNo, String airline, String dep_city,
			String arr_city, Date dep_date, Date arr_date, String dep_time,
			String arr_time, String firstSeats, Double firstSeatsFare,
			String busSeats, Double busSeatsFare) {
		super();
		this.flightNo = flightNo;
		this.airline = airline;
		this.dep_city = dep_city;
		this.arr_city = arr_city;
		this.dep_date = dep_date;
		this.arr_date = arr_date;
		this.dep_time = dep_time;
		this.arr_time = arr_time;
		this.firstSeats = firstSeats;
		this.firstSeatsFare = firstSeatsFare;
		this.busSeats = busSeats;
		this.busSeatsFare = busSeatsFare;
	}

	public String getFlightNo() {
		return flightNo;
	}

	public void setFlightNo(String flightNo) {
		this.flightNo = flightNo;
	}

	public String getAirline() {
		return airline;
	}

	public void setAirline(String airline) {
		this.airline = airline;
	}

	public String getDep_city() {
		return dep_city;
	}

	public void setDep_city(String dep_city) {
		this.dep_city = dep_city;
	}

	public String getArr_city() {
		return arr_city;
	}

	public void setArr_city(String arr_city) {
		this.arr_city = arr_city;
	}

	public Date getDep_date() {
		return dep_date;
	}

	public void setDep_date(Date dep_date) {
		this.dep_date = dep_date;
	}

	public Date getArr_date() {
		return arr_date;
	}

	public void setArr_date(Date arr_date) {
		this.arr_date = arr_date;
	}

	public String getDep_time() {
		return dep_time;
	}

	public void setDep_time(String dep_time) {
		this.dep_time = dep_time;
	}

	public String getArr_time() {
		return arr_time;
	}

	public void setArr_time(String arr_time) {
		this.arr_time = arr_time;
	}

	public String getFirstSeats() {
		return firstSeats;
	}

	public void setFirstSeats(String firstSeats) {
		this.firstSeats = firstSeats;
	}

	public Double getFirstSeatsFare() {
		return firstSeatsFare;
	}

	public void setFirstSeatsFare(Double firstSeatsFare) {
		this.firstSeatsFare = firstSeatsFare;
	}

	public String getBusSeats() {
		return busSeats;
	}

	public void setBusSeats(String busSeats) {
		this.busSeats = busSeats;
	}

	public Double getBusSeatsFare() {
		return busSeatsFare;
	}

	public void setBusSeatsFare(Double busSeatsFare) {
		this.busSeatsFare = busSeatsFare;
	}

	@Override
	public String toString() {
		return "FlightInformationDTO [flightNo=" + flightNo + ", airline="
				+ airline + ", dep_city=" + dep_city + ", arr_city=" + arr_city
				+ ", dep_date=" + dep_date + ", arr_date=" + arr_date
				+ ", dep_time=" + dep_time + ", arr_time=" + arr_time
				+ ", firstSeats=" + firstSeats + ", firstSeatsFare="
				+ firstSeatsFare + ", busSeats=" + busSeats + ", busSeatsFare="
				+ busSeatsFare + "]";
	}
	
}
