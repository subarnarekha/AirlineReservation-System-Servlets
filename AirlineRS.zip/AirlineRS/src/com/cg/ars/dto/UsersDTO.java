package com.cg.ars.dto;

public class UsersDTO {
	
	private String username;
	private String pwd;
	private String role;
	private String mobileNo;
	public UsersDTO() {
		super();
	}
	public UsersDTO(String username, String pwd, String role, String mobileNo) {
		super();
		this.username = username;
		this.pwd = pwd;
		this.role = role;
		this.mobileNo = mobileNo;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	@Override
	public String toString() {
		return "UsersDTO [username=" + username + ", pwd=" + pwd + ", role="
				+ role + ", mobileNo=" + mobileNo + "]";
	}
	
	

}
