package com.cg.ars.service;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import com.cg.ars.dao.AirlineDAO;
import com.cg.ars.dao.IAirlineDAO;
import com.cg.ars.dto.BookingInformationDTO;
import com.cg.ars.dto.BookingsDbDTO;
import com.cg.ars.dto.FlightInformationDTO;
import com.cg.ars.dto.SearchDTO;
import com.cg.ars.dto.SearchResultDTO;
import com.cg.ars.exception.ARSException;

public class AirlineService implements IAirlineService {

	IAirlineDAO airDao = new AirlineDAO();

	@Override
	public void insertFlight(FlightInformationDTO flight) throws ARSException {
		// TODO Auto-generated method stub
		airDao.flightDb(flight);
	}

	@Override
	public List<FlightInformationDTO> viewFlight() throws ARSException {
		// TODO Auto-generated method stub
		return airDao.viewFlightDb();
	}

	@Override
	public List<BookingInformationDTO> viewBookingInfo() throws ARSException {
		// TODO Auto-generated method stub
		return airDao.viewBookingInfoDb();
	}

	@Override
	public String login(String username, String password) {
		// TODO Auto-generated method stub
		return airDao.loginDb(username, password);
	}

	@Override
	public String loginCustomer(String username, String password) {
		// TODO Auto-generated method stub
		return airDao.loginCustomer(username, password);
	}

	
	@Override
	public void signUp(String name, String mob, String pass) {
		// TODO Auto-generated method stub
		airDao.signUp(name, mob, pass);
	}

	@Override
	public List<SearchResultDTO> searchFl(SearchDTO search) {
		// TODO Auto-generated method stub
		System.out.println("in service");
		String flightNo;
		String airline;
		String dep_city;
		String arr_city;
		Date dep_date;
		Date arr_date;
		String dep_time;
		String arr_time;
		String firstSeats;
		Double firstSeatsFare;
		String busSeats;
		Double busSeatsFare;

		int infNo = search.getInfants();
		int adltNo = search.getAdults();
		String type = search.getType();
		int totalNo = infNo + adltNo;
		double totalfare;

		List<FlightInformationDTO> flightlist = new ArrayList<FlightInformationDTO>();
		List<SearchResultDTO> searchres = new ArrayList<SearchResultDTO>();
		flightlist = airDao.searchFl(search);
		if (type.equalsIgnoreCase("FC")) {
			for (FlightInformationDTO flightsDto : flightlist) {
				SearchResultDTO sresult = new SearchResultDTO();

				flightNo = flightsDto.getFlightNo();
				System.out.println(flightNo);
				airline = flightsDto.getAirline();
				arr_city = flightsDto.getArr_city();
				dep_city = flightsDto.getDep_city();
				// busSeatsFare=flightsDto.getBusSeatsFare();
				firstSeatsFare = flightsDto.getFirstSeatsFare();
				arr_time = flightsDto.getArr_time();
				dep_time = flightsDto.getDep_time();
				dep_date = flightsDto.getArr_date();
				arr_date = flightsDto.getDep_date();
			
					totalfare = firstSeatsFare * totalNo;
					sresult.setTotal_fare(totalfare);
			

				sresult.setAirline(airline);
				sresult.setDestn(arr_city);
				sresult.setSrc(dep_city);
				sresult.setFlightNo(flightNo);
				sresult.setArr_time(arr_time);
				sresult.setDep_time(dep_time);
				sresult.setDep_date(dep_date);
				sresult.setArr_date(arr_date);
				sresult.setSeatsFare(firstSeatsFare);
				sresult.setTotTickets(totalNo);
				sresult.setType(type);
				// sresult.setDuration(duration);

				searchres.add(sresult);
			}
		} else if (type.equalsIgnoreCase("Business")) {
			for (FlightInformationDTO flightsDto : flightlist) {
				SearchResultDTO sresult = new SearchResultDTO();

				flightNo = flightsDto.getFlightNo();
				airline = flightsDto.getAirline();
				arr_city = flightsDto.getArr_city();
				dep_city = flightsDto.getDep_city();
				busSeatsFare = flightsDto.getBusSeatsFare();
				// firstSeatsFare=flightsDto.getFirstSeatsFare();
				arr_time = flightsDto.getArr_time();
				dep_time = flightsDto.getDep_time();
				dep_date = flightsDto.getArr_date();
				arr_date = flightsDto.getDep_date();

				totalfare = busSeatsFare * totalNo;
				sresult.setTotal_fare(totalfare);
				sresult.setAirline(airline);
				sresult.setDestn(arr_city);
				sresult.setSrc(dep_city);
				sresult.setFlightNo(flightNo);
				sresult.setArr_time(arr_time);
				sresult.setDep_time(dep_time);
				sresult.setDep_date(dep_date);
				sresult.setArr_date(arr_date);
				sresult.setSeatsFare(busSeatsFare);
				sresult.setTotTickets(totalNo);
				// sresult.setDuration(duration);
				sresult.setType(type);

				searchres.add(sresult);
			}
		}
		// return airDao.searchFl(search,trip);
		return searchres;
	}

	@Override
	public SearchResultDTO bookDisp(int no) {
		return null;
	}

	@Override
	public void insertSer(List<SearchResultDTO> serdata) {
		airDao.insertSer(serdata);
	}

	@Override
	public SearchResultDTO select(String flightNo) {
		return airDao.select(flightNo);
	}

	@Override
	public int bookDb(BookingInformationDTO book,String flightnum) throws ARSException {
		return airDao.bookDb(book,flightnum);

	}

	@Override
	public void clearSearch() {
		airDao.clearSearch();
	}

	@Override
	public void update(String flightnum,int numbers,String type) {
		// TODO Auto-generated method stub
		airDao.update(flightnum, numbers,type);
	}

	@Override
	public List<FlightInformationDTO> adminSearchOne(Date date, String place) {
		return airDao.adminSearchOne(date, place);
	}

	@Override
	public void updateCustomers(int id, String mail,String uname) {
		airDao.updateCustomers( id, mail,uname);
		
	}

	@Override
	public List<BookingsDbDTO> adminSearchTwo(String flightNum) {
		return airDao.adminSearchTwo(flightNum);
	}
	@Override
	public List<FlightInformationDTO> showexecDetails(String src,String dest) {
		// TODO Auto-generated method stub
		System.out.println("HELLO");
		return airDao.showexecDetailsDB(src, dest);
	}

	@Override
	public List<FlightInformationDTO> showexecDetailsPeriodDB(Date date1,Date date2) {
		// TODO Auto-generated method stub
		return airDao.showexecDetailsPeriodDB(date1, date2);
	}

	@Override
	public List<BookingInformationDTO> showbookingInfo(String email,
			String bookingid) {
		// TODO Auto-generated method stub
		return airDao.showbookingInfo(email, bookingid);
	}

	@Override
	public String getFlightNumber(String bookingid) {
		// TODO Auto-generated method stub
		return airDao.getFlightNumberdb(bookingid);
	}

	@Override
	public int getBookingidSession(String username) {
		// TODO Auto-generated method stub
		return airDao.getBookingidSession(username);
	}

	@Override
	public BookingInformationDTO getBookInfo(int bookid2) {
		// TODO Auto-generated method stub
		
		return airDao.getBookInfo(bookid2);
	}

	@Override
	public void updateOnCancel(int nos, String classType, String fnum) {
		
		airDao.updateOnCancel(nos, classType, fnum);
	}

	@Override
	public int cancelTicket(int bookid2) {
		return airDao.cancelTicket(bookid2);
	}

	@Override
	public String getFlightInfo(String flightnum,String type) {
		// TODO Auto-generated method stub
		return airDao.getFlightInfo(flightnum, type);
	}

	/*@Override
	public int createSeq(int seatN, String flightnum) {
		// TODO Auto-generated method stub
		return airDao.createSeq(seatN, flightnum);
	}*/
	

	
}
