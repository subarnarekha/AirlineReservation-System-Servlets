package com.cg.ars.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.cg.ars.exception.ARSException;


public class DbUtil {
	
	static Connection conn=null;
	private static final Logger myLog=Logger.getLogger(DbUtil.class);

	public static Connection getConnection() throws ARSException  {
			
			try {
				InitialContext ic = new InitialContext();
				DataSource ds = (DataSource) ic.lookup("java:jboss/datasources/MyDS");
				conn = ds.getConnection();
				if(conn!=null){
					System.out.println("connection established..........");
				myLog.info("Connection Established With Database...");
				}
					else{
						System.out.println("no connection");
					}
			} catch (NamingException | SQLException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
				myLog.info("Problem in establishing"+e.getMessage());
				throw new ARSException("Problem in establishing connection");
			}
			
		return conn;
	}

}
